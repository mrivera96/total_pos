<?php $__env->startSection('content'); ?>
    <?php echo $__env->make('dashboard.content_header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="card ">

        <div class="card-header bg-light">
            <h3 class="card-title m-auto"><?php echo e($user->name); ?> <?php echo e($user->last_name); ?></h3>
            <a href="<?php echo e(route('user.delete', $user->id)); ?>"><i class="nav-icon fas fa-trash-alt float-right"></i></a>
        </div>

        <div class="card-body">
            <form method="POST" action="<?php echo e(route('user.update', $user->id)); ?>">
                <?php echo method_field('PUT'); ?>
               <?php echo $__env->make('users.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\smartecpos\resources\views/users/edit.blade.php ENDPATH**/ ?>