<?php $__env->startSection('content'); ?>


    <?php if($status==0): ?>
        <div class="mt-10 jumbotron bg-warning text-center">

            <div class="alert alert-warning m-auto" role="alert">
                <i class="fas fa-exclamation-triangle"> Lo sentimos, el usuario administrador no puede ser eliminado.</i>
            </div>
            <a class="btn btn-warning" href="<?php echo e(route('dashboard')); ?>"> Aceptar</a>
        </div>
        <?php elseif($status==1): ?>
        <div class="mt-10 jumbotron bg-success text-center">
            <div class="alert alert-success m-auto" role="alert">
                El usuario ha sido eliminado correctamente.
            </div>
            <a class="btn btn-success" href="<?php echo e(route('dashboard')); ?>"> Aceptar</a>
        </div>
    <?php endif; ?>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\smartecpos\resources\views/messages/userDelete.blade.php ENDPATH**/ ?>