<?php $__env->startSection('content'); ?>

    <?php if($status==1): ?>
        <div class="mt-10 jumbotron bg-success text-center">
            <div class="alert alert-success m-auto" role="alert">
                ¡Usuario actualizado correctamente!
            </div>
            <a class="btn btn-success" href="<?php echo e(route('dashboard')); ?>"> Aceptar</a>
        </div>

    <?php elseif($status==0): ?>
        <div class="alert alert-warning mb-5" role="alert">
            Ha ocurrido un error al actualizar el usuario. Intenta de nuevo.
        </div>
        <a class="btn btn-outline-primary mt-5" href="#"> Regresar</a>
    <?php endif; ?>
    <?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\smartecpos\resources\views/messages/userEdit.blade.php ENDPATH**/ ?>