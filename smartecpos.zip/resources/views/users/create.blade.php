@extends('layouts.master')
@section('content')
    @include('dashboard.content_header')

@endsection
